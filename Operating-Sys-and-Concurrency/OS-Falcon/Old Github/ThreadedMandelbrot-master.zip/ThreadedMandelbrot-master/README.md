# ThreadedMandelbrot
This is a multi-threaded implementation for generating Mandelbrot images, with a given set-up.  
Made to run the Raspberry pi, with "make".



