# Serial Mandelbrot
C++ code for making Mandelbrot images with one thread.
