﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;

namespace ParticleLab.Particles
{
    public class ParticleEmitter
    {

        private Dictionary<int, Particle> m_Particles = new Dictionary<int, Particle>();
        private Texture2D m_texSmoke;
        private Texture2D m_texFire;
        private MyRandom m_Random = new MyRandom();

        private TimeSpan m_Rate;
        private int m_SourceX;
        private int m_SourceY;
        private int m_ParticleSize;
        private int m_Speed;
        private TimeSpan m_Lifetime;
        private TimeSpan m_Switchover;

        public Vector2 Gravity { get; set; }

        public ParticleEmitter(ContentManager Content, TimeSpan Rate, int SourceX, int SourceY, int Size, int Speed, TimeSpan Lifetime, TimeSpan Switchover)
        {
            m_Rate = Rate;
            m_SourceX = SourceX;
            m_SourceY = SourceY;
            m_ParticleSize = Size;
            m_Speed = Speed;
            m_Lifetime = Lifetime;
            m_Switchover = Switchover;

            m_texSmoke = Content.Load<Texture2D>("Smoke");
            m_texFire = Content.Load<Texture2D>("Fire");

            this.Gravity = new Vector2(0, 0);
        }

        public int ParticleCount
        {
            get { return m_Particles.Count; }
        }

        private TimeSpan m_Accumulated = TimeSpan.Zero;

        /// <summary>
        /// Generates new particles, updates the state of existing ones and retires expired particles.
        /// </summary>
        public void Update(GameTime gameTime)
        {
            //
            // Generate particles at the specified rate
            m_Accumulated += gameTime.ElapsedGameTime;
            while (m_Accumulated > m_Rate)
            {
                m_Accumulated -= m_Rate;

                //for (int i = 0; i < 15; i++)
                {
                    Particle p = new Particle(
                        m_Random.Next(),
                        new Vector2(m_SourceX, m_SourceY),
                        m_Random.NextCircleVector(),
                        (float)m_Random.NextGaussian(m_Speed, Math.Sqrt(m_Speed)),
                        m_Lifetime,
                        m_texFire);

                    if (!m_Particles.ContainsKey(p.Name))
                    {
                        m_Particles.Add(p.Name, p);
                    }
                }
            }

            //
            // For any existing particles, update them, if we find ones that have expired, add them
            // to the remove list.
            List<int> RemoveMe = new List<int>();
            foreach (Particle p in m_Particles.Values)
            {
                p.Lifetime -= gameTime.ElapsedGameTime;
                if (p.Lifetime < TimeSpan.Zero)
                {
                    //
                    // Add to the remove list
                    RemoveMe.Add(p.Name);
                }
                else
                {
                    //
                    // Only if we have enough elapsed time, and then move/rotate things
                    // based upon elapsed time, not just the fact that we have received an update.
                    if (gameTime.ElapsedGameTime.Milliseconds > 0)
                    {
                        //
                        // Update its position
                        p.Position += (p.Direction * (p.Speed * (gameTime.ElapsedGameTime.Milliseconds/1000.0f)));

                        //
                        // Have it rotate proportional to its speed
                        p.Rotation += (p.Speed * (gameTime.ElapsedGameTime.Milliseconds / 100000.0f));
                    }

                    if (p.Texture != m_texSmoke && p.Lifetime < m_Switchover)
                    {
                        p.Texture = m_texSmoke;
                    }

                    //
                    // Apply some gravity
                    p.Direction += this.Gravity;
                }
            }

            //
            // Remove any expired particles
            foreach (int Key in RemoveMe)
            {
                m_Particles.Remove(Key);
            }
        }

        /// <summary>
        /// Renders the active particles
        /// </summary>
        public void Draw(SpriteBatch spriteBatch)
        {

            Rectangle r = new Rectangle(0, 0, m_ParticleSize, m_ParticleSize);
            foreach (Particle p in m_Particles.Values)
            {
                r.X = (int)p.Position.X;
                r.Y = (int)p.Position.Y;
                spriteBatch.Draw(
                    p.Texture,
                    r,
                    null,
                    Color.White,
                    p.Rotation,
                    new Vector2(p.Texture.Width / 2, p.Texture.Height / 2),
                    SpriteEffects.None,
                    0);
            }
        }
    }
}
